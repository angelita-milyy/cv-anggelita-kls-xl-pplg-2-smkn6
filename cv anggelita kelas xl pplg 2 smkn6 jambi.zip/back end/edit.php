<?php
session_start();
if (!isset($_SESSION["login"]) ){
    header ("Location: login.php");
        exit;
}
$database= mysqli_connect('localhost','root','','anggelita');//menampilkan Nama database
$hapus = $_GET ["no"]; //fungsi hapus
$data= mysqli_query ($database,"SELECT*FROM angel WHERE no=$hapus");

if(isset ($_POST["tombol"])){
    $no = $_POST ["no"];
    $nama = $_POST ["nama"];
    $alamat = $_POST ["alamat"];
    $no_hp = $_POST ["no_hp"];
    $skill = $_POST ["skill"];
    $pendidikan = $_POST ["pendidikan"];
    $pekerjaan = $_POST ["pekerjaan"];

    $edit = "UPDATE angel SET
    nama = '$nama',
    alamat = '$alamat',
    no_hp= '$no_hp',
    skill= '$skill',
    pendidikan = '$pendidikan'
    pekerjaan = '$pekerjaan'
    WHERE no=$hapus";

    mysqli_query($database,$edit);
    
    //cek apabila data sudah tersimpan
    if (mysqli_affected_rows($database)>0){
        echo "<script>
        alert ('Data Berhasil Diubah');
        document.location.href='index.php';
        </script>";
    } else{
        echo "<script>
        alert ('Data Gagal Diubah');
        document.location.href='index.php';
        </script>";
    }
}

?>
<!DOCTYPE html>
<head>
    <title>Edit Data</title>
</head>
<body>

<?php
    while($cari= mysqli_fetch_assoc ($data)):
    ?>
    <h2>Edit Data</h2>
    <form method="POST">
    <input type="hidden" name="no" value="<?= $cari ['no'];?>">
<ul>
<li><label >Nama</label></li>
<li><input type="text" name="nama" value="<?= $cari ['nama'];?>"></li>
    <li><label >alamat</label></li>
    <li><input type="text" name="alamat" value="<?= $cari ['alamat'];?>"></li>
    <li><label >No hp </label></li>
    <li><input type="text" name="no_hp" value="<?php echo $cari  ['no_hp'];?>"></li>
    <li><label >skill </label></li>
    <li><input type="text" name="skill" value="<?php echo $cari  ['skill'];?>"></li>
    <li><label >pendidikan </label></li>
    <li><input type="text" name="pendidikan" value="<?php echo $cari  ['pendidikan'];?>"></textarea></li>
    <li><label >pekerjaan </label></li>
    <li><input type="text" name="pekerjaan" value="<?php echo $cari  ['pekerjaan'];?>"></textarea></li>
    <li><button type="submit" name="tombol">Perbaharuin data</button></li>
</ul>
<?php
    endwhile;
    ?>
    </form>
</body>
</html>