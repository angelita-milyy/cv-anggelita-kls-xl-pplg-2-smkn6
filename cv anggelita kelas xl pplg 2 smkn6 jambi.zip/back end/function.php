<?php
$database= mysqli_connect('localhost','root','','anggelita');

function query ($query){
     global $database;
    $tampilkan = mysqli_query ($database,$query);
    $wadahkosong = [];
    while($data = mysqli_fetch_assoc ($tampilkan)){
        $wadahkosong [] = $data;
    }
    return $wadahkosong;
}

function tambah1 ($data){
    global $database;
    $nama = $_POST ["nama"];
    $alamat = $_POST ["alamat"];
    $no_hp = $_POST ["no_hp"];
    $skill = $_POST ["skill"];
    $pendidikan = $_POST ["pendidikan"];
    $pekerjaan = $_POST ["pekerjaan"];
    $tambah = "INSERT INTO angel VALUE
    ('','$nama','$alamat','$no_hp','$skill','$pendidikan','$pekerjaan')";

    mysqli_query($database,$tambah);
    return mysqli_affected_rows($database);
}


function hapus ($hapus){
    global $database;
    mysqli_query ($database, "DELETE FROM angel where no=$hapus");
    return mysqli_affected_rows($database);
}

 
?>