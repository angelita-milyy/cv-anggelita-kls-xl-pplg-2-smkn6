<?php
require 'function.php';
$cari= mysqli_query ($database,"SELECT*FROM angel");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>cv anggelita</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
<div class="header">
<div class="gambar"> <img src="gambar.png" alt="">
<?php
    foreach ($cari as $cari2):
    ?>
</div>
<h1>anggelita</h1>
<h3>menggambar</h3>
<?php
    endforeach;
    ?>
</div>
<div class="main">
    <div class="left">
        <h2>informasi indetitas</h2>
        <p><strong>nama</strong> <?= $cari2 ['nama'];?></p>
        <p><strong>alamat</strong> <?= $cari2 ['alamat'];?></p>
        <p><strong>no_hp</strong> <?php echo $cari2 ['no_hp'];?></p> 
        <p><strong>skill</strong> <?php echo $cari2 ['skill'];?></p>
        <p><strong>pekerjaan</strong> <?php echo $cari2 ['pekerjaan'];?></p>
        <h2>pendidikan</h2>
        <p><strong>Sekolah Dasar</strong> sd persada 1</p>
        <p><strong>Sekolah Menengah Pertama</strong> smp xaverius musi rawas</p>
        <p><strong>Sekolah Menengah Kejuruan </strong> smk 6 kota jambi</p> 
</div>
    <div class="right">
        <h2>pekerjaan</h2>
        <p><strong>Dirumah</strong>:menyapu</p>
        <p><strong>Disekolah</strong>:belajar</p>
        <h2>kepribadian</h2>
        <p><strong>kepribadian</strong></p>
        <li>imut</li>
        <li>baik hati</li>
        <li>tidak sombong</li>
    </div>
</body>
</html>